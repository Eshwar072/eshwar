import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RoomServiceService {

  private baseUrl = 'http://localhost:8990'; // Replace with your actual API base URL

  constructor(private http: HttpClient) {}

  addRoom(room: any): Observable<any> {
    const url = `${this.baseUrl}/room/save`;
    return this.http.post<any>(url, room);
  }
  // setHotelId(roomId: number, hotelId: number): Observable<any> {
  //   const url = `${this.baseUrl}/room/setHotelId/${roomId}/${hotelId}`;
  //   return this.http.put(url, null); 
  // }
  setHotelId(roomId: number, hotelId: number) :Observable<any>{

    return this.http.put<any>(`http://localhost:8990/setHotelId/${roomId}/${hotelId}`,{});
}
setHotelOwnerToHotel(hotelId: number, ownerId: number): Observable<any> {
  return this.http.put<any>(`http://localhost:8990/hotels/setHotelOwnerToHotel/${hotelId}/${ownerId}`, {});
}


}
