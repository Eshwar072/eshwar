import { Injectable } from '@angular/core';
import { GuestHardCodedAuthenticationService } from './guest-hard-coded-authentication.service';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class GuestRouteGaurdServiceService implements CanActivate {

  constructor(private guestHardCodedAuthenticationService: GuestHardCodedAuthenticationService, private router: Router) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if (this.guestHardCodedAuthenticationService.isGuestLoggedIn()) {
      return true;
    } else {
      // Redirect to the login page or another route
      this.router.navigate(['/GuestLogin']);
      return false;
    }
  }
}