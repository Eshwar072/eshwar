export class RoomInformation 
{
    roomId:number
    roomNumber:number
    roomPrice:number
    roomDescription:string
    roomcapacityAdults:string
    ownerId:number
    
    constructor(
      roomid:number,
      roomnumber:number,
      roompriceperday:number,
      roomdescription:string,
      roomimageurl:string,
      numberofpeople:string,
      
   
    ){
      this.roomid=roomid;
      this.roomnumber=roomnumber;
      this.roompriceperday=roompriceperday;
      this.roomdescription=roomdescription;
      this.roomimageurl=roomimageurl;
      this.numberofpeople=numberofpeople;
    }

}