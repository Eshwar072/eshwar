import { HotelServicesList } from './hotel-services-list';

describe('HotelServicesList', () => {
  it('should create an instance', () => {
    expect(new HotelServicesList()).toBeTruthy();
  });
});
