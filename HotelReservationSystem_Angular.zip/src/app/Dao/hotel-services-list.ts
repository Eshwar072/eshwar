export class HotelServicesList {
   
    hotelserviceid:number;
    hotelservicename:string;
        constructor(hotelserviceid:number,hotelservicename:string){
            this.hotelserviceid=hotelserviceid;
            this.hotelservicename=hotelservicename;
        }
    }
