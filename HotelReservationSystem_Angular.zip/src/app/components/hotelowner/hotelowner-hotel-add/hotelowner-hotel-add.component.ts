import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelowner-hotel-add',
  templateUrl: './hotelowner-hotel-add.component.html',
  styleUrls: ['./hotelowner-hotel-add.component.css']
})
export class HotelownerHotelAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
