import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { RoomServiceService } from 'src/app/services/room-service.service';

@Component({
  selector: 'app-hotelowner-hotel-room-add',
  templateUrl: './hotelowner-hotel-room-add.component.html',
  styleUrls: ['./hotelowner-hotel-room-add.component.css']
})
export class HotelownerHotelRoomAddComponent {
  ownerId: number;
  hotelId: number;
  id: number;
  roomid: string;
  roomId: number;
  room: any = {
    roomId: 0,
    roomNumber: 1,
    roomPrice : 0,
    roomType: '',
    roomcapacityAdult:0,
    roomcapacityChildern:0,
    isReserved:'vacant', // Add the roomType property
  };
  

  constructor(private roomService: RoomServiceService, private router: Router, private location:Location) {}

  onSubmit(addRoom: NgForm) {
    this.roomService.addRoom(this.room).subscribe(
      (roomResponse: any) => {
        if (roomResponse) {
          this.room = roomResponse;
          this.id = this.room.roomId;
          this.roomid = this.id.toString();
          this.roomId = Number(this.roomid);
          this.hotelId = Number(sessionStorage.getItem('hotelId'));
          console.log('Hotel Id in Room add component', this.hotelId);
          console.log(this.hotelId);
          this.setHotelIdtoroom(this.roomId);
          this.router.navigate(['/hotelownerhotellist']);
          // this.refreshPage();
          
        } else {
          alert('Invalid Data ..');
        }
      }
    );
  }
  // refreshPage() {
  //   this.location.go(this.location.path());
  // }
  setHotelIdtoroom(roomid1: number) {
    this.hotelId = Number(sessionStorage.getItem('hotelId'));
    console.log('Hotel Id fetched = ', this.hotelId);

    this.roomService
      .setHotelId(roomid1, this.hotelId)
      .subscribe((data) => {
        console.log('hotel ID added successful', data);  
              
      });
  }
  // cancel() {
  //   // Navigate back to the previous page (you may adjust the route based on your application)
  //   this.router.navigate(['/hotelownerhotellist']);
  // }
}