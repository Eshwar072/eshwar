import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelowner-hotel-update',
  templateUrl: './hotelowner-hotel-update.component.html',
  styleUrls: ['./hotelowner-hotel-update.component.css']
})
export class HotelownerHotelUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
