import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelowner-profile',
  templateUrl: './hotelowner-profile.component.html',
  styleUrls: ['./hotelowner-profile.component.css']
})
export class HotelownerProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
