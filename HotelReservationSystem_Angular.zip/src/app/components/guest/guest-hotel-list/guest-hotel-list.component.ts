import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guest-hotel-list',
  templateUrl: './guest-hotel-list.component.html',
  styleUrls: ['./guest-hotel-list.component.css']
})
export class GuestHotelListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
