import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestHotelListComponent } from './guest-hotel-list.component';

describe('GuestHotelListComponent', () => {
  let component: GuestHotelListComponent;
  let fixture: ComponentFixture<GuestHotelListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GuestHotelListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GuestHotelListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
