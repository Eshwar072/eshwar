import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-logout',
  templateUrl: './admin-logout.component.html',
  styleUrls: ['./admin-logout.component.css']
})
export class AdminLogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
