
package com.SimpleBanking;

import java.sql.SQLException;
import java.util.Scanner;

public class BankMainApp {
	static boolean flag=true;
	
	public static void main(String[] args) throws SQLException {
		
		
		while(flag) {
			Scanner sc=new Scanner(System.in);
		System.out.println("\t*****Menu*****");
		System.out.println(String.format("%-15s  %-10s","1.Check Balance","2.Deposit"));
		System.out.println(String.format("%-15s  %-10s","3.Withdraw","4.Money Transfer"));
		System.out.println(String.format("%-15s ", "5.ministatement")+"\n");
		
		System.out.println("Enter your choice");
		int i=0;
		try {
			i =sc.nextInt();
			}catch (Exception e) {
				System.out.println("Choice must be single digit numeric");
				
			}		
		
	
		
		switch(i) {
		case 1:BankOperations.checkBalance();
		break;
		case 2:BankOperations.deposit();
		break;
		case 3:BankOperations.withdraw();
		break;
		case 4:BankOperations.moneyTransfer();
		break;
		case 5: BankOperations.ministatement();
		break;
				
		default:System.err.println("invalid inputs");
		
		}
		System.out.println("do you want to continue,y to continue,any other key to stop");
		char choice=sc.next().charAt(0);
		if(choice!='y' ) {

			break;
		}
		else {

			continue;
		}
		
	}
		
}}




