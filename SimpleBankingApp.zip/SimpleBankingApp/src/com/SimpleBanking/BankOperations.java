package com.SimpleBanking;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.BreakIterator;
import java.util.Scanner;

public class BankOperations {

	private static Connection con;
	private static Statement st;
	private static String s;
	private static ResultSet rs;
	private static Scanner sc=new Scanner(System.in);;


	public static void checkBalance() throws SQLException {

		con=BankDataBase.getConnection();
		st=con.createStatement();
		System.out.println("enter your acc no");

		String acc_no=sc.next();
		rs= st.executeQuery("select * from banking where acc_no= '"+acc_no+"'");
		if(rs.next()) {
			
				System.out.println("You available balance is :"+rs.getFloat("balance")+"\n");
		}
		else {
			System.err.println("invalid Account number");
		}
		
		con.close();
		st.close();
		
		}
	public static void deposit() throws SQLException {
		con=BankDataBase.getConnection();
		st=con.createStatement();
		sc=new Scanner(System.in);
		System.out.println("enter acc_no");
		String acc_no=sc.next();
		rs=st.executeQuery("select * from banking where acc_no= '"+acc_no+"'");
		if(!isValidAccountNumber(acc_no)) {
			System.err.println("inavlid input");
		}
		
		else if(rs.next()&&rs.getString("acc_no").matches(acc_no)){
			
			System.out.println("enter amount to deposit");
			float deposit=sc.nextFloat();
			if(deposit<=0) {
				System.err.println("please deposit greterthan 0");
			}else {

				s="update Banking set balance=balance+"+deposit+" where acc_no="+acc_no;
				st.executeUpdate("insert into ministatement (acc_no,txn_name,reference,amount) values("+acc_no+",'Credit',' by self  ',"+deposit+")");
				int i =st.executeUpdate(s);
				if(i>0) {
					rs=st.executeQuery("select * from banking where acc_no="+acc_no);
					while(rs.next()) {
						System.out.println("balance updated "+rs.getFloat("balance"));

					}


				}}}
		else{
			System.out.println("Invalid user");
		}


		con.close();
		st.close();
		//		rs.close();
	}
	public static void withdraw() throws SQLException {
		con=BankDataBase.getConnection();
		st=con.createStatement();

		System.out.println("enter your acc_no");

		String acc_no=sc.next();
		rs=st.executeQuery("select * from banking where acc_no='"+acc_no+"'");
		if(!isValidAccountNumber(acc_no)) {
			System.err.println("invalid input");
		}


		else if(rs.next()&& rs.getString("acc_no").matches(acc_no)){
			System.out.println("enter amount to withdraw");
			float withdraw=sc.nextFloat();
			
			if(withdraw<=0) {
				System.err.println("please enter withdarw amount >0");
			}else if(rs.next()&& withdraw>rs.getFloat("balance")) {
				System.err.println("you have insufficient balance");

			}else {

			s="update Banking set balance=balance-"+withdraw+" where acc_no="+acc_no;
			st.executeUpdate("insert into ministatement (acc_no,txn_name,reference,amount) values("+acc_no+",'Debit',' By Self ',"+withdraw+")");

			int i =st.executeUpdate(s);
			if(i>0) {
				rs=st.executeQuery("select * from banking where acc_no="+acc_no);
				while(rs.next()) {
					System.out.println(" you have withdrawn & your current balance is "+rs.getFloat("balance")+"\n");

				}
			}


			}

		}
		else {
			System.out.println("invalid account number");
		}
		con.close();
		st.close();
		//rs.close();
	}


	public static void moneyTransfer() throws SQLException {
		con=BankDataBase.getConnection();

		st=con.createStatement();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your acc no");
		String  acc_no=sc.next();
		String query="select * from banking where acc_no='"+acc_no+"'";
		rs=st.executeQuery(query);
		if(!isValidAccountNumber(acc_no)) {
			System.err.println("inavalid input");
		}
		else if(rs.next()&&rs.getString("acc_no").matches(acc_no)) {
			
				System.out.println("enter amount to transfer");
				long tamount=sc.nextLong();
				if(tamount<=0) {
					System.err.println("transfer amount should be gretaer than 0");

				}
				else if(rs.getFloat("balance")<tamount){
					System.err.println("insufficient balance");

				}
				else {
				System.out.println("enter acc no to whom you want to transfer");
				String receiver=sc.next();
				rs=st.executeQuery("select * from banking where acc_no= " +receiver);
				if(rs.next()) {					
				
				st.executeUpdate("update Banking set balance=balance- "+tamount+" where acc_no="+acc_no);
				st.executeUpdate("update Banking set balance=balance+ "+tamount+" where acc_no="+receiver);
				if(acc_no.matches(receiver)) {
					st.executeUpdate("insert into ministatement (acc_no,txn_name,reference,amount) values("+acc_no+",'Debit',' self transfer ',"+tamount+")");
				}else {				
				
				st.executeUpdate("insert into ministatement (acc_no,txn_name,reference,amount) values("+acc_no+",'Debit','transfer to "+receiver+"',"+tamount+")");
				st.executeUpdate("insert into ministatement (acc_no,txn_name,reference,amount) values("+receiver+",'Credit','transfer by "+acc_no+"',"+tamount+")");
				}
				rs=st.executeQuery(query);
				while(rs.next()) {
					System.out.println("transfer amount of Rs "+tamount+" is successfull and avaliable balance="+rs.getFloat("balance")+"\n");
				}
		}else {
			System.err.println("invalid account number");
		}
				}
				
			
		}
		else {
					System.err.println("invalid account number");
				}
			}
				
	private static boolean isValidAccountNumber(String acc_no) throws SQLException {
		
		if( acc_no.length()==12&&acc_no.matches("^[0-9]+$")) {
			return true;

		}else {
			return false;
		}

	}

//	public static void exit() throws SQLException{
//		System.out.println(" thank you  for using our services");
//		BankMainApp.flag=false;
//		con.close();
//		st.close();
//		rs.close();
//	}

	public static void ministatement() throws SQLException {
		con=BankDataBase.getConnection();
		st=con.createStatement();
		System.out.println("enter your acc no");

		String acc_no=sc.next();
		
		if(!isValidAccountNumber(acc_no)) {
			System.err.println("invalid input");
		}
		else {
			s="select* from ministatement where acc_no= "+acc_no+" order by txn_date desc limit 5" ;
			rs=st.executeQuery(s);
			if(rs!=null) {
				
			System.out.println("+---------------+-------------+--------------+----------------------------+-------------------------+");
			System.out.println("|    acc_no     |    amount   |   txn_name   |             reference      |        txn_date         |");
			System.out.println("+---------------+-------------+--------------+----------------------------+-------------------------+");
			while(rs.next()) {
				System.out.println(String.format("|  %-10s |  %-10.2f |  %-10s  |  %-25s |  %-20s  |",rs.getString("acc_no"),rs.getFloat("amount"),rs.getString("txn_name"),rs.getString("reference"),rs.getTimestamp("txn_date")));
			}
			System.out.println("+---------------+-------------+--------------+----------------------------+-------------------------+");
		}
			else {
				System.err.println("invalid Account number");
			}
	}
}
}







