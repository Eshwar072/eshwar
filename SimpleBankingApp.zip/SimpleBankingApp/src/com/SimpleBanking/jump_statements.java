package com.SimpleBanking;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import javax.swing.GroupLayout.ParallelGroup;

public class jump_statements {
	public static void main(String[] args) {
//		int array[]= {
//	1,2,34,56,4,5,};
//		for(int i=0;i<array.length;i++) {
//			if((i+1)%2==0) {
//			System.out.println(array[i]);
//			
//		}
		
//		String s="mahesh";
//		String rev="";
//		
//		for(int i=0;i<s.length();i++) {
//			rev=s.charAt(i)+rev;
//			
//	}
//		System.out.println(rev);
		
		
		int largest=0;
		int temp;
		int ar[]= {
				1,2,34,56,4,5,};
					for(int i=0;i<ar.length;i++) {
						System.out.println(i+" ");
						for(int j=0;j<ar.length;j++) {
							System.out.print(j+" ");
							if(ar[i]<ar[j]) {
								temp=ar[i];
								ar[i]=ar[j];
								ar[j]=temp;
							}
						}
						
		}System.out.println(Arrays.toString(ar));
		System.out.println(ar[ar.length-2]);
					}}
		
	


