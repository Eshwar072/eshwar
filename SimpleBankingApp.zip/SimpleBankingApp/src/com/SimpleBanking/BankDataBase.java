package com.SimpleBanking;
import java.sql.Connection;
import java.sql.DriverManager;
public class BankDataBase {
	

		private static String driver="com.mysql.cj.jdbc.Driver";
		private static String url="jdbc:mysql://localhost:3306/10224_2023";
		private static String un="root";
		private static String pass="root";
		private static Connection conn;
		
		public static Connection getConnection() {
			try {
				Class.forName(driver);
				conn=DriverManager.getConnection(url,un,pass);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return conn;
		
	}
	}


