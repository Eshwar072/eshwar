package com.edu.hms.exceptions;

public class GuestNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GuestNotFoundException(String message) {
		super(message);
	}
}
