package com.edu.hms.entity;

public class Views {
    public static class Public { }
    public static class Internal extends Public { }
}

