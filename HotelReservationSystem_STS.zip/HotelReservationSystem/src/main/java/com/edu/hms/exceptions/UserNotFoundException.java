package com.edu.hms.exceptions;

public class UserNotFoundException {

}
