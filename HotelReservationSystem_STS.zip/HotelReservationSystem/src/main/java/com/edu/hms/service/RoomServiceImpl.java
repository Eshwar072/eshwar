package com.edu.hms.service;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.hms.entity.Hotel;
import com.edu.hms.entity.Room;
import com.edu.hms.exceptions.GlobalException;
import com.edu.hms.repository.RoomRepository;

@Service
public class RoomServiceImpl implements RoomService {

	@Autowired
	private RoomRepository roomRepository;

	@Override
	public Room saveRoom(@Valid Room room) {
		return roomRepository.save(room);
	}
	//
	@Transactional
    public void setHotelId(int roomId, int hotelId) {
        Room room = roomRepository.findById(roomId).orElse(null);

        if (room != null) {
            // Assuming that 'hotelId' is the ID of the hotel you want to associate with the room
            Hotel hotel = new Hotel();
            hotel.setHotelId(hotelId);

            room.setHotel(hotel);

            roomRepository.save(room);
        } else {
            // Handle the case where the room with the given ID is not found
            System.out.println("Room not found with ID: " + roomId);
        }
    }
	
	public void setHotelOwnerAndHotelId(int roomId, int ownerId, int hotelId) throws GlobalException {
        Optional<Room> optionalRoom = roomRepository.findById(roomId);

        if (optionalRoom.isPresent()) {
            Room room = optionalRoom.get();
            room.getHotel().getHotelOwner().setOwnerId(ownerId);
            room.getHotel().setHotelId(hotelId);
            room.setIsReserved("Vacant");
            roomRepository.save(room);
        } else {

            throw new GlobalException("Room not found with ID: " + roomId);
        }
    }
	
		

	@Override
	public List<Room> getAllRooms() {
		return roomRepository.findAll();
	}

	@Override
	public Room getRoomById(int rId) throws GlobalException {
		return roomRepository.findById(rId).orElseThrow(() -> new GlobalException("Room not found with ID: " + rId));
	}

	@Override
	@Transactional
	public Room updateRoom(int roomId, @Valid Room updatedRoom) throws GlobalException {
		Room existingRoom = getRoomById(roomId);

		// Update properties of the existing room with the new values
//		existingRoom.setRoomNo(updatedRoom.getRoomNo());
		existingRoom.setRoomType(updatedRoom.getRoomType());
		existingRoom.setRoomPrice(updatedRoom.getRoomPrice());
		existingRoom.setRoomcapacityAdults(updatedRoom.getRoomcapacityAdults());
		existingRoom.setRoomcapacityChildren(updatedRoom.getRoomcapacityChildren());
		existingRoom.setIsReserved(null);

		return existingRoom;
	}

	@Override
	public void deleteRoom(int rId) {
		roomRepository.deleteById(rId);
	}

	@Override
	public List<Room> searchByRoomType(String roomType) {
		return roomRepository.findByRoomTypeContaining(roomType);
	}


    @Override
    public List<Room> searchByHotel(int hId) {
        return roomRepository.findByHotelId(hId);
    }

    @Override
    public List<Room> searchByCapacity(int adults, int children) {
        return roomRepository.findByRoomcapacityAdultsAndRoomcapacityChildren(adults, children);
    }

    @Override
    public List<Room> filterByPrice(double minPrice, double maxPrice) {
        return roomRepository.findByRoomPriceBetween(minPrice, maxPrice);
    }

    @Override
    public List<Room> getAvailableRooms() { 
        return roomRepository.findRoomsWithNoReservations();
    }

    @Override
    public List<Room> getReservedRooms() {
 
        return roomRepository.findRoomsWithReservations();
    }

    @Override
    public List<Room> getReservedRooms(String startDate, String endDate) { 
        Date start = Date.valueOf(startDate);
        Date end = Date.valueOf(endDate);
        return roomRepository.findReservedRoomsByDateRange(start, end);
    }

	 

}
