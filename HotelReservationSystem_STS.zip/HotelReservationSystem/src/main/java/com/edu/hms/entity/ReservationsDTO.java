package com.edu.hms.entity;

public class ReservationsDTO {

}
